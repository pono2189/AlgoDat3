import java.util.ArrayList;
import java.util.HashMap;

/**
 * graphTemplate
 */

import java.util.*;

public class GraphTemplate{
    ArrayList<Node> nodes;
    ArrayList<Node> minPriorityQueue;

    GraphTemplate(){
    	nodes = new ArrayList<Node>();
        minPriorityQueue = new ArrayList<Node>();
    }
    
    GraphTemplate(int ndistance){
      	 nodes = new ArrayList<Node>();
       	 minPriorityQueue = new ArrayList<Node>();
       	 Node parent = null;
       	 int distance = ndistance;
       	 }
    
    
    void addNode(Node node){
    	for (int i = 0; i < nodes.size(); i++){
    		if((nodes.get(i).label).equals(node.label)){ //checks if the node you want to add already exists
    			return; 
    		}
    	}
    	nodes.add(node); //the new node is added to the list of unused nodes
    }
    
    void removeNode(Node node){
    	for (int i = 0; i < nodes.size(); i++){
    		//iterates through adjacentNodes of every element in nodes
    		for (Map.Entry<Node, Integer> mapElement : nodes.get(i).adjacentNodes.entrySet()) { 
                Node key = (Node)mapElement.getKey(); 		
                if(key.label.equals(node.label)){ 			 // if node is connected to the node at i
                	nodes.get(i).adjacentNodes.remove(node); // node is removed from the adjacentNodes of that node
                } 			
    		}
    	}
    	for (int i = 0; i < nodes.size(); i++){
    		if((nodes.get(i).label).equals(node.label)){ //checks if the node you want to remove even exists
    			nodes.remove(node);
    			return; 
    		}
    	}
    	System.out.println("Error - " + node.label + " does not even exist\n");		
    }
    
    public Node extractNode(){
    	if (minPriorityQueue.size() == 0){
    		System.out.println("Error - list is empty\n" );
    	}
    	Node node = minPriorityQueue.get(0);
    	minPriorityQueue.remove(0);
    			return node; 	
    	
    	 // if we dont break out of the loop 
    	// that means that the node is not in the minPriorityQueue and the Error-Message is printed 
    	
    }
    
    // implement additional constructors
    // implement method for adding a node
    // implement method for removing a node
    // implement method for sorting the min-priority Queue
    // implement method for extracting an element from the min-priority Queue 
    // implement Djikstra (in another class)

}