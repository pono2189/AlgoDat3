import java.util.ArrayList;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;

public class Node {
    String label; //name of the node 
    HashMap<Node,Integer> adjacentNodes = new HashMap(); // Pair connected node + weight
    Node parent = null;
    int distance = Integer.MAX_VALUE; // infinite distance by default

    Node(){
        label = "";
        adjacentNodes = new HashMap<Node,Integer>();
    }

    Node(String name){
        label = name;
        adjacentNodes = new HashMap<Node, Integer>();
    }
    
    Node(String name, Node parent){
    	this.label = name; 
    	this.parent = parent;
    	adjacentNodes = new HashMap<Node, Integer>();
    }
    Node(String name, int distance){
    	this.label = name; 
    	this.distance = distance; 
    	adjacentNodes = new HashMap<Node, Integer>();
    }
    
    Node(String name, Node parent, int distance){
    	this.label = name; 
    	this.parent = parent;
    	this.distance = distance; 
    	adjacentNodes = new HashMap<Node, Integer>();
    }

    public void addConnection(Node destination, int distance){
    	adjacentNodes.put(destination,  distance);
    }
    
//    public void removeConnection(Node node){
//    	for (Map.Entry<Node, Integer> mapElement : this.adjacentNodes.entrySet()) { 
//            Node key = (Node)mapElement.getKey(); 		
//            if(key.label.equals(node.label)){ 	//if there is a connection from "this" to node
//            	this.adjacentNodes.remove(node); 	// node is removed from the adjacentNodes of "this"
//            } 			
//		}
//    	node.removeConnection(this); //if there is a connection from node to this, it is removed as well
//    }
    public void removeConnection(Node c){
		if (this.adjacentNodes.containsKey(c.label)){ 	
			this.adjacentNodes.remove(c); 		
		}
	}
    
    public void setParent(Node node){
    	this.parent = node;
    }
    
    public void setDistance(int ndis){
    	this.distance = ndis;
    }
    // implement additional constructors
    // implement method for adding a connection
    // implement method for removing a connection
    // implement methods for manipulating the parent and distance

}


