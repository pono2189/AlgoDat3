import java.util.*;

public class shortestPath {
	public static void swap(ArrayList<Node> arr, int i, int j){ //function to swap two elements of an array
		Node temp = arr.get(i);
		arr.set(i,arr.get(j));
		arr.set(j, temp);
	}
	
	public static void sort(ArrayList<Node> arr){
		for (int i = 0; i < arr.size(); i++ ){ 		// repeat sorting for every element in the array
			for (int j = 0; j < arr.size()-1; j++)  // iterate through array and always compare only 
													// the two elements next to each other
		         if (arr.get(j).distance > arr.get(j+1).distance) // if the distance element of j is bigger than of j+1 swap the two 
		            swap(arr, j, j+1);
		}
		
	}
	
	public static void dijkstra(Node source, GraphTemplate graph){     
		
		int size = graph.nodes.size();
		
		if(!graph.nodes.contains(source)){
			System.out.println("Error - the source node is not in the graph");
		}
		if(source.adjacentNodes.size() == 0){
			System.out.println("Error - the source node does not have any connections"); // if there are no connections leading away from the source node
		}
		graph.minPriorityQueue = new ArrayList<Node>();
		for (int i = 0; i < graph.nodes.size(); i++){  // copies all elements of nodes in minpriorityQueue
			graph.minPriorityQueue.add(graph.nodes.get(i));
		}
		
		source.distance = 0;	 // sets distance of source node to 0 so it is the first node in the queue
		sort(graph.minPriorityQueue); // because the distance of every other node is infinit the source node is at position 0
		System.out.println("Start node: " + graph.minPriorityQueue.get(0).label);
		
		Node parent = new Node();
		
		while(graph.minPriorityQueue.size()> 0){ //while not all elements are used in the shortest path yet	
			sort(graph.minPriorityQueue); //sort by distance
			parent = graph.extractNode();
			// save smallest distance in parent
			//delete that element from the queue
			if (parent.distance == Integer.MAX_VALUE){
				continue;
			}
			//Iterator<Map.Entry<Node, Integer>> it = parent.adjacentNodes.entrySet().iterator(); 
			//while (it.hasNext()) {  //iterates through the child nodes of parent
				// Map.Entry<Node, Integer> mapElement = (Map.Entry<Node,Integer>)it.next();  
	        
			for (Map.Entry<Node, Integer> it : parent.adjacentNodes.entrySet()){    
	        	Node key = (Node)it.getKey(); 
				int val = parent.distance + it.getValue(); // saves the distance of the parent node + the weight of the edge to the new node
				
				if( (key.distance == Integer.MAX_VALUE)|| key.distance > val){  
					key.distance = val;
					key.parent = parent;
				}
			}
			}
		return;	
	}	
	
	public static void printPath(GraphTemplate graph){ // prints the whole graph
		for(Node node : graph.nodes){
			if (node.distance == Integer.MAX_VALUE){
			System.out.println(node.label + ": " + "No Connection");
			}
			else{
				System.out.println(node.label + ": " + node.distance);
			}
		}
	} 
	

	public static void main (String [] args){
		GraphTemplate arr1 = new GraphTemplate();
		Node k = new Node(" k ", 3);
		Node l = new Node(" l ", -12);
		Node m = new Node(" m ", 0);
		Node n = new Node(" n ", 100);
		Node o = new Node(" o ", 13);
		Node p = new Node(" p ", -2);
		
		arr1.addNode(k);
		arr1.addNode(l);
		arr1.addNode(m);
		arr1.addNode(n);
		arr1.addNode(o);
		arr1.addNode(p);
		arr1.addNode(p); //tries to add the same node twice
		
		sort(arr1.nodes);
		System.out.println("Array sorted by distance: ");
		for (Node node:arr1.nodes){
			System.out.println(node.label + ": \t" + node.distance);
		}
		System.out.println(" ");
		
		System.out.println("Example for shortest path: ");
		GraphTemplate graph = new GraphTemplate();
		Node a = new Node(" a ");
		Node b = new Node(" b ");
		Node c = new Node(" c ");
		Node d = new Node(" d ");
		Node e = new Node(" e ");
		Node f = new Node(" f ");
		Node g = new Node(" g ");
		Node h = new Node(" h ");
		Node i = new Node(" i ");
		Node j = new Node(" j ");
		
		graph.addNode(a);
		graph.addNode(b);
		graph.addNode(c);
		graph.addNode(d);
		graph.addNode(e);
		graph.addNode(f);
		
		b.addConnection(c, 3);
		a.addConnection(b, 1);
		a.addConnection(e, 7);
		// c has 3 adjacent nodes
		c.addConnection(e, 3); // 1. e
		c.addConnection(d, 8); // 2. d
		c.addConnection(f, 6); // 3. f
		c.addConnection(f, 6); // tries to add the connection from c to f again but the number of adjacent nodes remains 3
		e.addConnection(f, 1);
		f.addConnection(d, 3);
		f.addConnection(c, 1);
		
		
		
		for (int y = 0; y < graph.nodes.size(); y++){
			System.out.println(graph.nodes.get(y).label+ " has " + graph.nodes.get(y).adjacentNodes.size() + " adjacent Nodes");  
		}
		//System.out.println(" + " + graph.nodes.size()); 
		dijkstra(a, graph);
		//System.out.println(graph.nodes.size());  
		
		printPath(graph);
		
		GraphTemplate map = new GraphTemplate();
		Node bremen = new Node(" Bremen ");
		Node hannover = new Node(" Hannover ");
		Node berlin = new Node(" Berlin ");
		Node leipzig = new Node(" Leipzig ");
		Node jena = new Node(" Jena ");
		Node weimar = new Node(" Weimar ");
		Node erfurt = new Node(" Erfurt ");
		Node muenchen = new Node(" Muenchen ");
		Node augsburg = new Node(" Augsburg ");
		Node freiburg = new Node(" Freiburg ");
		Node stuttgart = new Node(" Stuttgart ");
		Node nuernberg = new Node(" Nuernberg ");
		Node frankfurt = new Node(" Frankfurt ");
		Node mainz = new Node(" Mainz ");
		Node leverkusen = new Node(" leverkusen ");
		Node essen = new Node(" Essen ");
		Node moenchengladbach = new Node(" Moenchengladbach ");
		Node dortmund = new Node(" Dortmund ");
		Node gelsenkirchen = new Node(" Gelsenkirchen ");
		Node braunschweig = new Node(" Braunschweig ");
		Node mannheim = new Node (" Mannheim ");

		map.addNode(bremen);
		map.addNode(hannover);
		map.addNode(berlin);
		map.addNode(leipzig);
		map.addNode(jena );
		map.addNode(weimar);
		map.addNode(erfurt);
		map.addNode(muenchen);
		map.addNode(augsburg);
		map.addNode(freiburg);
		map.addNode(stuttgart);
		map.addNode(nuernberg);
		map.addNode(frankfurt);
		map.addNode(mainz);
		map.addNode(leverkusen);
		map.addNode(essen);
		map.addNode(moenchengladbach);
		map.addNode(dortmund);
		map.addNode(gelsenkirchen);
		map.addNode(braunschweig);
		map.addNode(mannheim);
		
		bremen.addConnection(hannover, 127);
		hannover.addConnection(braunschweig, 88);
		hannover.addConnection(dortmund, 211);
		berlin.addConnection(hannover, 300);
		berlin.addConnection(braunschweig, 227);
		berlin.addConnection(leipzig, 190);
		gelsenkirchen.addConnection(dortmund, 35);
		dortmund.addConnection(essen, 70);
		dortmund.addConnection(bremen, 234);
		essen.addConnection(gelsenkirchen, 48);
		essen.addConnection(leverkusen, 53);
		moenchengladbach.addConnection(essen, 33);
		leverkusen.addConnection(moenchengladbach, 85);
		leverkusen.addConnection(mainz, 185);
		leipzig.addConnection(jena, 105);
		jena.addConnection(nuernberg, 226);
		weimar.addConnection(jena, 25);
		weimar.addConnection(leipzig, 130);
		erfurt.addConnection(weimar, 23);
		erfurt.addConnection(frankfurt, 262);
		erfurt.addConnection(berlin, 237);
		frankfurt.addConnection(leverkusen, 196);
		frankfurt.addConnection(hannover, 573);
		frankfurt.addConnection(mainz, 43);
		frankfurt.addConnection(nuernberg, 224);
		mainz.addConnection(mannheim, 124);
		mannheim.addConnection(frankfurt, 124);
		nuernberg.addConnection(stuttgart, 210);
		nuernberg.addConnection(augsburg, 148);
		stuttgart.addConnection(mannheim, 90);
		stuttgart.addConnection(freiburg, 206);
		freiburg.addConnection(bremen, 1250);
		freiburg.addConnection(mannheim, 194);
		muenchen.addConnection(berlin, 840);
		muenchen.addConnection(nuernberg, 169);
		muenchen.addConnection(freiburg, 351);
		augsburg.addConnection(stuttgart, 164);
		augsburg.addConnection(muenchen, 79);
		
		System.out.println(" " );
		System.out.println("Map of german Cities:");
		dijkstra(weimar, map);
		printPath(map);
		
		
		
		//dijkstra(erfurt, map);
		//printPath(map);
		

}
}