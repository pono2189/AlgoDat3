import java.util.*;
public class bubblesort { // i first implemented my sorting algorithm here but copied it into shortestPath.java 
						  // because i found it more structured that way

	public static void swap(ArrayList<Node> arr, int i, int j){ //function to swap two elements of an array
		Node temp = arr.get(i);
		arr.set(i,arr.get(j));
		arr.set(j, temp);
	}
	
	public static void sort(ArrayList<Node> arr){ 	
		for (int i = 0; i < arr.size(); i++ ){ 		// repeat sorting for every element in the array
			for (int j = 0; j < arr.size()-1; j++)  // iterate through array and always compare only 
													// the two elements next to each other
		         if (arr.get(j).distance > arr.get(j+1).distance) // if the distance element of j is bigger than of j+1 swap the two 
		            swap(arr, j, j+1);
		}
		
	}


}


